//
//  ViewController.m
//  录音
//
//  Created by RenShen on 2019/5/29.
//  Copyright © 2019 RenShen. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController ()
@property (nonatomic, strong)AVAudioRecorder *avAudioRecorder;
@property (weak, nonatomic) IBOutlet UIButton *recorderBTN;
@property (nonatomic, strong) AVAudioPlayer *avPlayer;//播放
@property (nonatomic, strong) NSURL *pathURL;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //设置录音的路径
    NSString *path = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:@"text.caf"];
    _pathURL = [NSURL URLWithString:path];
    NSDictionary *configDic = @{// 编码格式
                                AVFormatIDKey:@(kAudioFormatLinearPCM),
                                // 采样率
                                AVSampleRateKey:@(11025.0),
                                // 通道数
                                AVNumberOfChannelsKey:@(2),
                                // 录音质量
                                AVEncoderAudioQualityKey:@(AVAudioQualityMin)
                                };
    _avAudioRecorder = [[AVAudioRecorder alloc]initWithURL:_pathURL settings:configDic error:nil];
    

     [_recorderBTN addTarget:self action:@selector(TouchDown) forControlEvents:UIControlEventTouchDown];
    [_recorderBTN addTarget:self action:@selector(TouchUpOutside) forControlEvents:UIControlEventTouchUpOutside];
    [_recorderBTN addTarget:self action:@selector(TouchDragExit) forControlEvents:UIControlEventTouchDragExit];
    [_recorderBTN addTarget:self action:@selector(TouchDragEnter) forControlEvents:UIControlEventTouchDragEnter];
}

- (IBAction)startRecording:(id)sender {
    NSLog(@"发送");
    if ([_avAudioRecorder isRecording]) {
        NSLog(@"录音时长---%f",_avAudioRecorder.currentTime);
        [_avAudioRecorder stop];
    }
   
}

- (IBAction)ennRecording:(id)sender {
        [_avAudioRecorder stop];
}

- (IBAction)playRecording:(id)sender {
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    [audioSession setActive:NO error:nil];
    
   [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [audioSession setActive:YES error:nil];
    //听筒模式播放
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];

    _avPlayer= [[AVAudioPlayer alloc]initWithContentsOfURL:_pathURL error:nil];
    
    //设置代理

    
    //将播放文件加载到缓冲区
    [_avPlayer prepareToPlay];
    [_avPlayer play];
}
-(void)TouchDown{
    //点击上去时候
    if (![self canRecord]) {
        NSLog(@"无权限访问麦克风");
        return;
    }
    NSLog(@"开始录音");
    [_recorderBTN setTitle:@"松开发送" forState:UIControlStateNormal];
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
  //这个类别允许你的应用中同时进行声音的播放和录制。当你的声音录制或播放开始后，其他应用的声音播放将会停止。主UI界面会照常工作。这时，即使屏幕被锁定或者设备为静音模式，音频回放和录制都会继续。
    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDuckOthers|AVAudioSessionCategoryOptionAllowAirPlay|AVAudioSessionCategoryOptionAllowBluetooth error:nil];
    
    [audioSession setActive:YES error:nil];
    _avAudioRecorder.meteringEnabled = YES;//录音测量，音贝等信息
    [_avAudioRecorder prepareToRecord];
    [_avAudioRecorder record];
}
-(void)TouchUpOutside{
    //外部抬起
    NSLog(@"取消发送");
    if ([_avAudioRecorder isRecording]) {
        [_avAudioRecorder stop];
        [_avAudioRecorder deleteRecording];
    }

    
}
-(void)TouchDragExit{
    //从内部拖到外部
    [_recorderBTN setTitle:@"松开取消" forState:UIControlStateNormal];
    
    
}
-(void)TouchDragEnter{
    //从外部拖到内部
    [_recorderBTN setTitle:@"松开发送" forState:UIControlStateNormal];
    
}
//权限
- (BOOL)canRecord {
    __block BOOL bCanRecord = YES;
    
    AVAudioSession *audioSession = [AVAudioSession sharedInstance];
    if ([audioSession respondsToSelector:@selector(requestRecordPermission:)]) {
        [audioSession performSelector:@selector(requestRecordPermission:) withObject:^(BOOL granted) {
            if (granted) {
                bCanRecord = YES;
            } else {
                bCanRecord = NO;
            }
        }];
    }
    return bCanRecord;
}
@end
