//
//  main.m
//  录音
//
//  Created by RenShen on 2019/5/29.
//  Copyright © 2019 RenShen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
