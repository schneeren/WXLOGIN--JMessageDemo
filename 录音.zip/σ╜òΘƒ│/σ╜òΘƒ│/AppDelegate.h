//
//  AppDelegate.h
//  录音
//
//  Created by RenShen on 2019/5/29.
//  Copyright © 2019 RenShen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

